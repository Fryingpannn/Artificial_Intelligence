Running the program.

- Run `pypy skeleton-tictactoe.py` OR
- `python skeleton-tictactoe.py` OR
- Copy paste the code in `skeleton-tictactoe.py` in a Jupyter Notebook or Google Colab and run it.
